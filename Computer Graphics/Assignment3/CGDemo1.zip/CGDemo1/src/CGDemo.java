public class CGDemo
{
	public static void main(String[] args)
	{
		DemoDisplay myDemo = new DemoDisplay();
	}
}