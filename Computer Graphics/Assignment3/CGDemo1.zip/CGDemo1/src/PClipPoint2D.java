class PClipPoint2D
{
	float x, y;
	char Label;

	PClipPoint2D(float x, float y, char Label){this.x = x; this.y = y; this.Label = Label;}
}