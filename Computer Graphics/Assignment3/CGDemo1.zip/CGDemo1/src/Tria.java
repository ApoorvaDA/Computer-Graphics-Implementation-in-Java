class Tria
{

    int iA;
    int iB;
    int iC;

    Tria(int i, int j, int k)
    {
        iA = i;
        iB = j;
        iC = k;
    }
}