
class Point3D
{

    float x;
    float y;
    float z;

    Point3D(double x, double y, double z)
    {
        this.x = (float)x;
        this.y = (float)y;
        this.z = (float)z;
    }
}