class DottedLines
{
	float xp, yp, xq, yq;
    char Label1, Label2;

    DottedLines(float xp, float yp, char Label1, float xq, float yq, char Label2)
    {
        this.xp = xp;
        this.xq = xq;
        this.yp = yp;
        this.yq = yq;
        this.Label1 = Label1;
        this.Label2 = Label2;
    }
}