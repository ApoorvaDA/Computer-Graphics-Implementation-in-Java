class Triangle
{

    Point2D A;
    Point2D B;
    Point2D C;

    Triangle(Point2D A, Point2D B, Point2D C)
    {
        this.A = A;
        this.B = B;
        this.C = C;
    }
}
