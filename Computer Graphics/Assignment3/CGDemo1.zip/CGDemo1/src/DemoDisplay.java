public class DemoDisplay
{
	DemoDisplay()
	{
		DemoDisplayFrame demoframe = new DemoDisplayFrame();
		demoframe.pack();
		demoframe.setSize(1000, 830);
		demoframe.setVisible(true);
	}
}